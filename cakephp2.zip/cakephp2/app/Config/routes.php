<?php

Router::connect('/', array('controller' => 'users', 'action' => 'login'));
Router::connect('/dashboard', array('controller' => 'users', 'action' => 'dashboard'));
//Router::connect('/', array('controller' => 'pages', 'action' => 'home'));
Router::connect('/page/*', array('controller' => 'pages', 'action' => 'cms_page'));
Router::connect('/contact-us', array('controller' => 'pages', 'action' => 'contactUs'));
Router::connect('/how-it-work', array('controller' => 'pages', 'action' => 'how_it_work'));
Router::connect('/how-it-works', array('controller' => 'pages', 'action' => 'how_it_work'));

Router::connect('/register', array('controller' => 'users', 'action' => 'register'));
Router::connect('/login', array('controller' => 'users', 'action' => 'login'));
Router::connect('/logout', array('controller' => 'users', 'action' => 'logout'));
Router::connect('/edit-profile', array('controller' => 'users', 'action' => 'edit_profile'));
Router::connect('/forgot-password', array('controller' => 'users', 'action' => 'forgot_password'));

CakePlugin::routes();

require CAKE . 'Config' . DS . 'routes.php';
