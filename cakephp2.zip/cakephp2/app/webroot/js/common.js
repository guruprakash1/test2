/*Utility Functions*/
function closeMsg(id) {
    $("#" + id).slideUp(400);
}
function closePopup(id) {
    $("#" + id).hide();
}
var siteUrl = $("#pageurl").val();

//Common Functions//
function escapeHtml(text) {
    return text
            .replace(/\s\s+/g, ' ')//Trim White Spcace
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
}
function log(blockId, text) {
    $log = $('#' + blockId);
    $log.append(($log.val() ? "\n" : '') + text);//Add text to log           
    $log[0].scrollTop = $log[0].scrollHeight - $log[0].clientHeight; //Autoscroll
}
function pr(data) {
    alert(JSON.stringify(data));
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31
            && (charCode < 48 || charCode > 57))
        return false;

    return true;
}
var joblam = {
    removeInvalidChars: function (d, a, c) { //onkeyup="joblam.removeInvalidChars('0-9A-Za-z', this, event);"
        var f = c != null ? c : event;
        var h = f.charCode ? f.charCode : f.keyCode;
        var g = String.fromCharCode(h);
        if (h < 32 || h > 222 || h == 37 || h == 39) {
            return;
        }
        var b = "[^" + d + "]";
        a.value = a.value.replace(new RegExp(b, "g"), "");
    }
}
function validateImgExt(id) {
    var value = $('#' + id).val();
    var ext = value.substring(value.lastIndexOf('.') + 1);
    var ext = ext.toLowerCase();
    var extList = new Array;
    extList = ["png", "gif", "ttf", "jpg", "jpeg", "bmp"];
    if ($.inArray(ext, extList) < 0) {
        $('#' + id).val('');
        alert("Invalid input file format! Please upload only IMAGE file");
        return false;
    } else {
        return true;
    }
}
function validateImage(id) {
    var value = $('#' + id).val();
    var ext = value.substring(value.lastIndexOf('.') + 1);
    var ext = ext.toLowerCase();
    var extList = new Array;
    extList = ["png", "gif", "ttf", "jpg", "jpeg", "bmp"];
    if ($.inArray(ext, extList) < 0) {
        $('#' + id).val('');
        alert("Invalid input file format! Please upload IMAGE file only");
        return false;
    }
    else {
        return true;
    }
}

function makeSeoUrl(name) {
    name = name.toLowerCase(); // lowercase
    name = name.replace(/^\s+|\s+$/g, ''); // remove leading and trailing whitespaces
    name = name.replace(/\s+/g, '-'); // convert (continuous) whitespaces to one -
    name = name.replace(/[^a-z-]/g, ''); // remove everything that is not [a-z] or -
    return name;
}

/*Utility Functions*/

function validateSubmit(done, msg) {
    if (done == '1') {
        $("#success_msg").slideUp(400);
        $("#error_msg").slideDown(400);
        $("#error_msg").html(msg);
        $('html, body').animate({
            scrollTop: 0
        }, 400);
        return false;
    } else {

        $("#success_msg").slideUp(400);
        $("#error_msg").slideUp(400);
        $("#sh_submit").hide();
        $("#sh_loaded").show();
        return true;
    }
}

function ajaxlike(status, pid) {
    $.post(url + "users/like", {
        'status': status,
        'pid': pid
    }, function (data) {
        if (data) {
            $('#status_' + pid).html(data);
        }
    });
}
function likein(id) {
    jQuery('#status_' + id).show();
}
function likeout(id) {
    jQuery('#status_' + id).hide();
}
///////////////////////////////////////XXXXXXXXXXXXXXXXX-By Prakash Starts-XXXXXXXXXXXXXXXXXXXXXXX\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

function chkEmailAvail(email) {
    $("#email_msg").html('');
    var url = $("#pageurl").val();
            var eml = /^([a-zA-Z0-9_\.\old_email-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var old_email = $("#old_email").val();
    if (email.match(eml)) {
        $("#emailloader_ajax").show();
        $.post(url + "users/ajaxChkEmailAvail", {
            'email': email,
            'old_email': old_email
        }, function (data) {
            if (data) {
                $("#email_msg").html(data);
                $("#emailloader_ajax").hide();
            }
        });
    }
}

function chkEmailSetAvail(email) {
    $("#email_msg").html('');
    var url = $("#pageurl").val();
            var eml = /^([a-zA-Z0-9_\.\old_email-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            var old_email = $("#old_email").val();
    if (email.match(eml)) {
        $("#emailloader_ajax").show();
        $.post(url + "settings/ajaxChkSetEmailAvail", {
            'email': email,
            'old_email': old_email
        }, function (data) {
            if (data) {
                $("#email_msg").html(data);
                $("#emailloader_ajax").hide();
            }
        });
    }
}

function chkUsernameAvail(username) {
    $("#usernameloader_ajax").show();
    var url = $("#pageurl").val(); //alert(url);exit;
    var old_uname = $("#old_username").val();
    if (!username) {
        $('#username_msg').html('');
        $("#usernameloader_ajax").hide();
        return false;
    }
    $.post(url + "users/ajaxChkUsernameAvail", {
        'username': username,
        'old_username': old_uname
    }, function (data) {
        if (data) {
            $("#username_msg").html(data);
            $("#usernameloader_ajax").hide();
        }
    });
}
function chkCountyAvail(country_name, lang) {

    if (country_name == '') {
        if (lang == "ita")
        {
            $("#county").html("<option value=''>Seleziona il Paese</option>");
            $("#town").html("<option value=''>Seleziona la Città</option>");
        } else {
            $("#county").html("<option value=''>--Select County--</option>");
            $("#town").html("<option value=''>--Select Town--</option>");
        }
    } else {
        $("#countryloader_ajax").show();
        if (lang == "ita")
        {
            $("#town").html("<option value=''>Seleziona la Citt&agrave;</option>");
        } else {
            $("#town").html("<option value=''>--Select Town--</option>");
        }

        var url = $("#pageurl").val();
        $.ajax({
            type: "POST",
            url: url + "users/ajaxChkCountyAvail",
            data: 'country=' + country_name + '&lang=' + lang,
            success: function (data) {
                $("#countryloader_ajax").hide();
                $("#county").html(data);
            }
        });
    }
}

$(document).ready(function () {
    $('#country').change(function () {
        $('#county').prop('selectedIndex', 0);
        $('#town').prop('selectedIndex', 0);
    });
    $('#county').change(function () {
        $('#town').prop('selectedIndex', 0);
    });
    $('#category_id').change(function () {
        $('#subcategory_id').prop('selectedIndex', 0);
    });
    //    $('form#registerForm').submit(function(){
    //        $(this).find('input[type=submit]').prop('disabled', true);
    //    });

    $("#submitBtn").click(function (event) {
        if ($('form#registerForm').validate()) {
            alert("Jai Jagannath Swami");
            return false;
            $(event.target).attr("disabled", "disabled");
        }
    });
});

function chkTownAvail(county_name, lang) {
    if (county_name == '') {
        if (lang == 'ita') {
            $("#town").html("<option value=''>Seleziona la Città</option>");
        }
        else
        {
            $("#town").html("<option value=''>--Select Town--</option>");
        }
    } else {
        $("#countyloader_ajax").show();
        var url = $("#pageurl").val();
        $.ajax({
            type: "POST",
            url: url + "users/ajaxChkTownAvail",
            data: 'county=' + county_name + '&lang=' + lang,
            success: function (data) {
                $("#countyloader_ajax").hide();
                $("#town").html(data);
            }
        });
    }
}

function chkSubCategoryAvail(category_id) {
    var url = $("#pageurl").val();
    $("#categoryloader_ajax").show();
    $.post(url + "projects/ajaxChkSubCategoryAvail", {
        'category_id': category_id
    }, function (response) {
        $("#categoryloader_ajax").hide();
        if (response.status == 'success') {
            $.each(response.subCategory, function (i, value) {
                $('#subcategory_id').append($('<option>').text(value).attr('value', value));
            });
        }
    }, 'json');
}
///////////////////////////////////////XXXXXXXXXXXXXXXXX-By Prakash Ends-XXXXXXXXXXXXXXXXXXXXXXX\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

function ajax_login() {
    alert('Jai Jagannath Swami');return false;
    var url = $("#pageurl").val();
    var username = $("#username").val();
    var password = $("#password").val();

    if (username == '') {
        $("#login-status-message").html("<span>You must specify a username to login.</span>").show().delay(3000).fadeOut();
        $("#username").focus();
    } else if (password == '') {
        $("#login-status-message").html("<span>You must specify a password to login.</span>").show().delay(3000).fadeOut();
        $("#password").focus();
    } else if (username && password) {
        $("#login-status-message").html("<div class='check-login'>Authenticating....</div>").show().delay(3000).fadeOut();
        $.post(url + "users/ajax_login", {
            "username": username,
            "password": password
        }, function (data) {
            if (data.status == 'success') {
                $("#login-status-message").html("<p>Login successfull.Redirecting...</p>").show().delay(10000).fadeOut();
                location.reload();
            } else if (data.status == 'error') {
                $("#login-status-message").html("<span>Invalid username or password.</span>").show().delay(3000).fadeOut();
            } else if (data.status == 'seller') {
                window.location = url + "edit-profile";
            }
        }, 'json');
    }
    return false;
}
function editCaption(imageId) {
    var url = document.getElementById('pageurl').value;
    $('#editCaption').fadeIn();
    $.post(url + "users/editCaption/", {
        "imageId": imageId
    }, function (data) {
        if (data) {
            $('#editCaption').html(data);
        }
    });
}
function editCaptionNow(imageId) {
    var url = document.getElementById('pageurl').value;
    $(".loaderDiv").show();
    var caption = $("#newCaption").val();
    if (caption) {
        $.post(url + "users/ajaxEditCaption/", {
            "imageId": imageId,
            "caption": caption
        }, function (data) {
            if (data) {
                $('#imageDiv_' + imageId).prop('title', caption);
                $("#editCaption").hide();
            }
        });
    }
}

function deletePortfolioImage(id) {
    if (confirm("Are you sure want to delete?")) {
        var url = $("#pageurl").val();
        $.post(url + "users/ajaxDeletePortfolioImage/" + id, function (data) {
            if (data.status = 'success') {
                $("#removePortfolioImage-" + id).remove();
            }
        }, 'json');
    }
}

function postComment(language) {
    var comment = $("#comment-data").val();
    var userId = $("#user_id").val();
    var projectId = $("#project_id").val();
    if (comment) {
        var url = $("#pageurl").val();
        $.post(url + "projects/ajaxPostComment", {
            'project_id': projectId,
            'comment': comment
        }, function (response) {
            if (response.status == 'success') {
                $('#comment-sec').load(url + "projects/ajaxLoadComment/" + projectId);
                $("#comment-message").css("color", "green").html((language == 'ita') ? "La tua richiesta è stata inoltrata, grazie!" : "Your comment regarding this project is posted.").show().delay(2000).fadeOut();
                $('#comment-box').delay(3000).fadeOut();
            } else if (response.status == 'error') {
                $("#comment-message").css("color", "red").html((language == 'ita') ? "Inserisci il tuo commento" : "Please enter your comment").show().delay(2000).fadeOut();
            }
        }, 'json');
    } else {
        $("#comment-message").css("color", "red").html((language == 'ita') ? "Inserisci il tuo commento" : "Please enter your comment").show().delay(2000).fadeOut();
    }
}

function openReplyBox(_this) {
    $('#reply-box').show();
    $('#reply-data').val("");
    $('#project_comment_id').val($(_this).attr("data-project-comment-id"));
}
function replyComment() {
    var reply = $("#reply-data").val();
    var projectId = $("#project_id").val();
    var projectCommentId = $("#project_comment_id").val();
    var url = $("#pageurl").val();
    if (reply) {
        $.post(url + "projects/ajaxReplyComment", {
            'project_id': projectId,
            'project_comment_id': projectCommentId,
            'comment': reply
        },
        function (response) {
            if (response.status == 'success') {
                $('#comment-sec').load(url + "projects/ajaxLoadComment/" + projectId);
                $("#reply-message").css("color", "green").html("Comment posted successfully.").show().delay(2000).fadeOut();
                $('#reply-box').delay(3000).fadeOut();
            }
        }
        , 'json');
    } else {
        $("#reply-message").css("color", "red").html("Please enter reply").show().delay(2000).fadeOut();
    }
}
function viewMore(viewMore_Id) {
    $("#view-more-loader").show();
    $('#view-more').fadeIn();
    var url = $("#pageurl").val();
    $.post(url + "users/ajaxViewMore", {
        'viewMore_Id': viewMore_Id
    }, function (response) {
        $("#view-more-loader").hide();
        if (response.status == 'success') {
            $('#viewmore-message').html(response.view_more);
        } else if (response.status == 'success') {
            $('#viewmore-message').html("No data found!!!");
        }
    }, 'json');
}
function deleteOfferFiles(id) {
    var result = confirm("Are you sure want to delete?");
    if (result) {
        var url = $("#pageurl").val();
        $.post(url + "projects/ajaxDeleteOfferFiles/" + id, function (data) {
            if (data.status = 'success') {
                //                window.location.assign(url + "edit-profile")                
                $("#removeOfferFiles-" + id).remove();
            }
        }, 'json');
    }
}

function updateMyCoverImage(coverImgForm) {
    var siteUrl = $("#pageurl").val();
    var imageData = $(coverImgForm).find('.image-editor').cropit('export');
    if (imageData) {
        $(".cover_image_btn").hide();
        $(".drag_text").text("Loading please wait...");
        $(coverImgForm).find('.hidden-image-data').val(imageData);
        var formData = $(coverImgForm).serialize();
        $.ajax({
            type: "POST",
            url: siteUrl + "users/ajaxUpdateCoverImage",
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.error == 0) {
                    $('#cover-photo').attr('src', response.imgsrc);
                    $("#update_cover_image").hide("slow");
                    $("#cover_image_container").show("slow");
                    $(".drag_text").text("Drag to Reposition Cover");
                    $(".cover_image_btn").show();
                }
            }
        });
    }
    return false;
}
function updateProfileImage() {
    var siteUrl = $("#pageurl").val();
    var imageData = $('#profile_image_editor').cropit('export');
    $('#profile_image_hidden_data').val(imageData);
    var formData = $("#profile_image_form").serialize();
    if (imageData) {
        $.ajax({
            type: "POST",
            url: siteUrl + "users/ajaxUpdateProfileImage",
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.error == 0) {
                    $('#profile-photo').attr('src', response.imgsrc);
                    $('.drop_pro').attr('src', response.imgsrc);
                    $('.profile_photo').find('img').attr('src', response.imgsrc);
                    $('#upload_profile_image').hide();
                }
            }
        });
    }
    return false;
}


function saveSearch() {
    var saveSearchName = $("#savesearchname").val();
    if (saveSearchName) {
        $("#save-search-loader").show();
        var siteUrl = document.getElementById('pageurl').value;
        var currentUrl = document.URL;
        $.post(siteUrl + "projects/ajaxSaveSearch", {
            "url": currentUrl,
            'name': saveSearchName
        }, function (response) {
            $("#save-search-loader").hide();
            if (response.status == "success") {
                $("#save-search-error-msg").css("color", "green").html("(You have saved " + saveSearchName + "  successfully)").show().delay(2000).fadeOut();
                $("#save-search-popup").delay(3000).fadeOut();
                $("#savesearchname").val("");
                $("#save_search_list").load(siteUrl + "projects/ajaxLoadSaveSearch");
            }
        }, 'json');
    } else {
        $("#save-search-error-msg").html("(Please enter a name)").show().delay(2000).fadeOut();
        $("#savesearchname").focus();
    }
}
function removeSaveSearch(id, name) {
    if (confirm("Are you sure you wnat to delete ?")) {
        var siteUrl = document.getElementById('pageurl').value;
        $.post(siteUrl + "projects/ajaxRemoveSaveSearch/" + id, function (response) {
            if (response.error == 0) {
                $("#save-search-list-" + id).remove();
                $("#save_search_list").load(siteUrl + "projects/ajaxLoadSaveSearch");
            }
        }, 'json');
    }
}

/*Post Project*/
function showSubcategory(val) {
    if (val == '') {
        $("#subcategory_id").html("<option value=''>Select</option>");
    } else {
        $("#sub_category_id").html("<option value=''>Select</option>");
        var url = $("#pageurl").val();
        $.ajax({
            type: "POST",
            url: url + "projects/ajaxShowSubcategory",
            data: 'category_id=' + val,
            success: function (data) {
                $("#subcategory_id").html(data);
            }
        });
    }
}
function showSubSubcategory(val) {
    if (val == '') {
        $("#sub_category_id").html("<option value=''>Select</option>");
    } else {
        var url = $("#pageurl").val();
        $.ajax({
            type: "POST",
            url: url + "projects/showSubSubcategory",
            data: 'subcategory_id=' + val,
            dataType: "json",
            success: function (response) {
                if (response.error == 0) {
                    $('#sub_category_id').prop('disabled', false);
                    $("#sub_category_id").html(response.selecthtml);
                } else {
                    $('#sub_category_id').prop('disabled', 'disabled');
                }

            }
        });
    }
}
/*Post Project*/

/*Edit Profile Start*/
function updateCoverImage() {
    var siteUrl = $("#pageurl").val();
    var imageData = $('#cover_image_editor').cropit('export');
    $('#cover_image_hidden_data').val(imageData);
    var formData = $("#cover_image_form").serialize();
    if (imageData) {
        $.ajax({
            type: "POST",
            url: siteUrl + "users/ajaxUpdateCoverImage",
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.error == 0) {
                    $('#cover-photo').attr('src', response.imgsrc);
                    $('.mini_cover').find('img').attr('src', response.imgsrc);
                    $('#upload_cover_image').hide();
                }
            }
        });
    }
    return false;
}
function updateProfileImage() {
    var siteUrl = $("#pageurl").val();
    var imageData = $('#profile_image_editor').cropit('export');
    $('#profile_image_hidden_data').val(imageData);
    var formData = $("#profile_image_form").serialize();
    if (imageData) {
        $.ajax({
            type: "POST",
            url: siteUrl + "users/ajaxUpdateProfileImage",
            data: formData,
            dataType: 'json',
            success: function (response) {
                if (response.error == 0) {
                    $('#profile-photo').attr('src', response.imgsrc);
                    $('.drop_pro').attr('src', response.imgsrc);
                    $('.profile_photo').find('img').attr('src', response.imgsrc);
                    $('#upload_profile_image').hide();
                }
            }
        });
    }
    return false;
}
/*Edit Profile End*/


function viewProjectCosts(uniq_id, curr_lang) {
    $('#project-cost-box').fadeIn();
    var siteUrl = $("#pageurl").val();
    $.post(siteUrl + "projects/ajaxProjectCost", {'uniq_id': uniq_id},
    function (response) {
        var project_cost_length = response[0].length;
        var costHtml = '';
        if (project_cost_length) {
            var date = (curr_lang == 'ita') ? 'Data' : 'Date';
            var cost = (curr_lang == 'ita') ? 'Ammontare' : 'Cost';
            var total = (curr_lang == 'ita') ? 'Totale' : 'Total';
            costHtml += '<table width="100%" cellpadding="2" cellspacing="2" style="border:1px solid #ccc; margin:10px 0px; line-height:20px;"><tr><th style="text-align:center;">' + date + '</th><th style="text-align:right;">' + cost + '</th></tr>';
            for (var i = 0; i < project_cost_length; i++) {
                var created = response[0][i][0].created;
                var currency = response[0][i].Project.currency == 1 ? '&euro;' : '&pound;';
                costHtml += '<tr><td style="text-align:center;">' + created + '</td><td style="text-align:right;">' + currency + ' ' + response[0][i].ProjectCost.amount + '</td></tr>';
            }
            var currency2 = response[1].Project.currency == 1 ? '&euro;' : '&pound;';
            costHtml += '<tr style="border-top:1px solid #ccc; font-weight:bold;"><td style="text-align:center;">' + total + '</td><td style="text-align:right;">' + currency2 + ' ' + response[1][0].total_amount + '</td></tr>';
            costHtml += '</table>';
        }
        $('#project-cost-message').html(costHtml);
    }
    , 'json');

}


function removeInvalidChars(d, a, c) { //onkeyup="removeInvalidChars('0-9A-Za-z', this, event);"
    var f = c != null ? c : event;
    var h = f.charCode ? f.charCode : f.keyCode;
    var g = String.fromCharCode(h);
    if (h < 32 || h > 222 || h == 37 || h == 39) {
        return;
    }
    var b = "[^" + d + "]";
    a.value = a.value.replace(new RegExp(b, "g"), "");
}


/* Back to top code */
!function (o) {
    o.fn.backTop = function (e) {
        var i = this, n = o.extend({
            position: 400,
            speed: 500,
            color: "white"
        }, e), t = n.position, c = n.speed, d = n.color;
        i.addClass("white" == d ? "white" : "red" == d ? "red" : "green" == d ? "green" : "black"), i.css({
            right: 40,
            bottom: 40,
            position: "fixed"
        }), o(document).scroll(function () {
            var e = o(window).scrollTop();
            e >= t ? i.fadeIn(c) : i.fadeOut(c)
        }), i.click(function () {
            o("html, body").animate({
                scrollTop: 0
            }, {
                duration: 1200
            })
        })
    }
}(jQuery);
/*Back to top code end */

