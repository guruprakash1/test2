<?php

App::uses('Controller', 'Controller');

class AppController extends Controller {

    public $components = array('Session', 'Auth', 'Custom', 'Email');

}
