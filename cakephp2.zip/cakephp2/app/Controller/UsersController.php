<?php
App::uses('AppController', 'Controller');

class UsersController extends AppController {

    public $name = 'Users'; //Controller name
    public $uses = array('User', 'Setting', 'Zipcode', 'Portfolio', 'Project', 'ProjectOffer', 'ContactUs'); //Model name
    public $components = array('Paginator', 'Captcha' => array('Model' => 'ContactUs', 'field' => 'security_code')); //Pagination
    public $helpers = array('Captcha');

    function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('testemail', 'login', 'ajax_login', 'success', 'logout', 'register', 'problem_login', 'reset_password', 'confirm', 'ajaxChkEmailAvail', 'ajaxChkUsernameAvail', 'ajaxChkCountyAvail', 'ajaxChkTownAvail', 'profile', 'ajaxViewMore', 'edit_profile');
        $this->layout = 'default';
    }

    public function dashboard() {
//        $this->layout = 'profile';
//        $user_id = $this->Session->read('Auth.User.id');
//
//        $fields = array('count(id) total', 'COUNT(IF(status = 0, 1, NULL)) as pending', 'COUNT(IF(status = 1, 1, NULL)) as open', 'COUNT(IF(status = 2, 1, NULL)) as progress', 'COUNT(IF(status = 3, 1, NULL)) as completed', 'COUNT(IF(status = 4, 1, NULL)) as cancel, SUM(IF(status = 3 and currency=1, budget, NULL)) as total_earn_euro, SUM(IF(status = 3 and currency=2, budget, NULL)) as total_earn_pound');
//        $getProject = $this->Project->find('first', array('conditions' => array('Project.user_id' => $user_id), 'fields' => $fields));
//        $this->set(compact('getProject'));
//
//        $fields2 = array('COUNT(Project.id) total', 'COUNT(IF(Project.status = 0, 1, NULL)) as pending', 'COUNT(IF(Project.status = 2, 1, NULL)) as progress', 'COUNT(IF(Project.status = 3, 1, NULL)) as completed', 'SUM(IF(Project.status = 3 and Project.currency = 1, Project.budget, NULL)) as total_earn_euro', 'SUM(IF(Project.status = 3 and Project.currency = 2, Project.budget, NULL)) as total_earn_pound');
//        $getProjectSeller = $this->Project->find('first', array('conditions' => array('Project.seller_id' => $user_id), 'recursive' => 0, 'fields' => $fields2));
//        $hourlyRate = $this->User->field('per_hour_rate', array('User.id' => $user_id));
//        $this->set(compact('getProjectSeller', 'hourlyRate'));
//        $sumOfProjects = $this->Project->query("SELECT SUM(`budget`) AS `totalProjectPrice` FROM `projects` WHERE `is_active`=1 AND `status`=3 AND (`user_id`={$user_id} OR `seller_id`={$user_id})");
//        $this->set(compact('sumOfProjects'));
    }

    public function profile($username = null) {
        $this->layout = "profile";
        $userDetails = $this->User->find('first', array('conditions' => array('User.username' => $username)));
        $getAllPortfolioImages = $this->Portfolio->find('all', array('conditions' => array('Portfolio.user_id' => $userDetails['User']['id'])));
        $this->loadModel('PaypalDetail');
        $paymentVerified = $this->PaypalDetail->find('count', array('conditions' => array('PaypalDetail.user_id' => $userDetails['User']['id'])));
        $this->set(compact('userDetails', 'getAllPortfolioImages', 'skillNames', 'paymentVerified'));
        if (in_array($userDetails['User']['type'], array(3, 4))) {
            $this->loadModel('UserSkill');
            $skillNames = explode("|", $this->UserSkill->getUserSkills($userDetails['User']['id']));
            $this->set(compact('skillNames'));
        }


        $projectCompleted = $this->Project->find("count", array("conditions" => array("Project.seller_id" => $userDetails['User']['id'], "Project.status" => 3)));
        $buyerWorkedWith = $this->Project->find("count", array("conditions" => array("Project.seller_id" => $userDetails['User']['id'], "Project.status" => 3), 'group' => array("Project.user_id")));
        $lastProjectDate = $this->Project->field("created", array("Project.seller_id" => $userDetails['User']['id'], "Project.status" => 3), "Project.created DESC");
        $this->set(compact('projectCompleted', 'buyerWorkedWith', 'lastProjectDate'));


        $this->loadModel("Feedback");
        $sellerActivities = $this->Project->find("all", array("conditions" => array("Project.seller_id" => $userDetails['User']['id'], "Project.status" => 3), "contain" => array("User"), "limit" => 10, "order" => "Project.created DESC"));
        $sellerActivitiesCount = count($sellerActivities);
        for ($i = 0; $i < $sellerActivitiesCount; $i++) {
            $sellerActivities[$i]['BuyerFedback'] = $this->Feedback->find("first", array("conditions" => array("Feedback.project_id" => $sellerActivities[$i]['Project']['id'], "Feedback.feedback_from" => $sellerActivities[$i]['User']['id'], "Feedback.feedback_to" => $userDetails['User']['id']), "contain" => array("FeedbackFrom")));
            $sellerActivities[$i]['SellerFedback'] = $this->Feedback->find("first", array("conditions" => array("Feedback.project_id" => $sellerActivities[$i]['Project']['id'], "Feedback.feedback_to" => $sellerActivities[$i]['User']['id'], "Feedback.feedback_from" => $userDetails['User']['id']), "contain" => array("FeedbackFrom")));
        }

        $buyerActivities = $this->Project->find("all", array("conditions" => array("Project.user_id" => $userDetails['User']['id'], "Project.status" => 3), "contain" => array("User"), "limit" => 10, "order" => "Project.created DESC"));
        $buyerActivitiesCount = count($buyerActivities);
        for ($i = 0; $i < $buyerActivitiesCount; $i++) {
            $buyerActivities[$i]['SellerFedback'] = $this->Feedback->find("first", array("conditions" => array("Feedback.project_id" => $buyerActivities[$i]['Project']['id'], "Feedback.feedback_from" => $buyerActivities[$i]['Project']['seller_id'], "Feedback.feedback_to" => $userDetails['User']['id']), "contain" => array("FeedbackFrom")));
            $buyerActivities[$i]['BuyerFedback'] = $this->Feedback->find("first", array("conditions" => array("Feedback.project_id" => $buyerActivities[$i]['Project']['id'], "Feedback.feedback_to" => $buyerActivities[$i]['Project']['seller_id'], "Feedback.feedback_from" => $userDetails['User']['id']), "contain" => array("FeedbackFrom")));
        }
        $this->set(compact('sellerActivities', 'buyerActivities'));
    }

    public function edit_profile() {
        $this->layout = "profile";
        if ($this->Session->read('Auth.User.type') != 1) {

            $userId = $this->Session->read('Auth.User.id');

            $getUserDetail = $this->User->findById($userId);

            // $getCountry = $this->Zipcode->find('list', array('fields' => array('country', 'country'), 'group' => 'Zipcode.country'));      //Showing All Country      
            $getCountry = $this->Zipcode->find('list', array('conditions' => array('Zipcode.country' => 'Italy'), 'fields' => array('country', 'country'), 'group' => 'Zipcode.country')); //Showing Only Itly      
            $this->set(compact('getCountry'));

            if (!empty($getUserDetail['User']['country'])) {
                $getCounty = $this->Zipcode->find('list', array('conditions' => array('Zipcode.country' => $getUserDetail['User']['country']), 'fields' => array('county', 'county'), 'group' => 'Zipcode.county'));
            }
            $this->set('getCounty', !empty($getCounty) ? $getCounty : NULL);

            if (!empty($getUserDetail['User']['county'])) {
                $getTown = $this->Zipcode->find('list', array('conditions' => array('Zipcode.county' => $getUserDetail['User']['county']), 'fields' => array('town', 'town'), 'group' => 'Zipcode.town'));
            }
            $this->set('getTown', !empty($getTown) ? $getTown : NULL);

            if (in_array($getUserDetail['User']['type'], array(3, 4))) {
                $this->loadModel('UserSkill');
                $getUserDetail['User']['skill'] = $this->UserSkill->getUserSkills($userId);
            }
            $portfolioImages = $this->Portfolio->find('all', array('conditions' => array('Portfolio.user_id' => $userId)));
            $this->loadModel('Subcategory');
            $subCategoryList = $this->Subcategory->find('list', array('fields' => array('id', 'name')));
            $this->loadModel('SubSubcategory');
            $subSubcategoryList = $this->SubSubcategory->find('list', array('fields' => array('id', 'name')));
            $this->set(compact('getUserDetail', 'portfolioImages', 'subCategoryList', 'subSubcategoryList'));


            if ($_SESSION["temp_session_id"]) {
                $this->loadModel('TempPortfolio');
                $this->TempPortfolio->deleteAll(array('user_id' => $userId, 'temp_session_id !=' => $_SESSION["temp_session_id"]), TRUE, TRUE);
            }

            if ($this->request->is('post')) {
                $data = $this->request->data;
                $data['User']['id'] = $userId;
                $data['User']['is_profile_completed'] = 1;
//                $data['User']['address'] = nl2br($data['User']['address']);
                if (!empty($data['User']['birthday'])) {
                    $expldeBday = explode('-', $data['User']['birthday']);
                    $data['User']['birthday'] = $expldeBday[2] . '-' . $expldeBday[1] . '-' . $expldeBday[0];
                }
                $isSaved = $this->User->save($data, array('validate' => FALSE));
                if ($isSaved) {
                    if (isset($data['User']['skill'])) {
                        $this->UserSkill->updateUserSkills($data['User']['skill']);
                    }
                    $sql = "INSERT INTO portfolios (user_id,image) SELECT user_id, image FROM temp_portfolios WHERE temp_session_id = {$_SESSION["temp_session_id"]}";
                    $this->Portfolio->query($sql);
                    $this->TempPortfolio->deleteAll(array('user_id' => $userId, 'temp_session_id' => $_SESSION["temp_session_id"]), FALSE, FALSE);
                    $this->Session->setFlash(__('Your profile details updated successfully.'), 'success_message');
                } else {
                    $this->Session->setFlash(__('Unable to update.Some error occured.'), 'error_message');
                }
                $this->redirect($this->referer());
            }
        }
        $_SESSION["temp_session_id"] = mt_rand();
    }

    public function register() {
        if (!$this->Session->read('Auth.User.id')) {        
            if ($this->request->is('post')) {
                $data = $this->request->data;
                if ($data['User']['captcha'] == $this->Captcha->getCode('ContactUs.security_code')) {
                    $this->User->userRegistration($data);
                    $insertedUserId = $this->User->getLastInsertID();
                    if ($insertedUserId) {
                        $this->redirect(HTTP_ROOT . "users/success/$insertedUserId");
                    } else {
                        $this->Session->setFlash(__('Invalid Username or Password, try again'), 'error_message');
                    }
                } else {
                    $this->Session->setFlash(__('Invalid Captcha Code.'), 'error_message');
                }
            }
        } else {
            $this->redirect(HTTP_ROOT);
        }
    }

    public function success($id, $option = NULL) {
        if ($id) {
            $userDetails = $this->User->findById($id);
            $this->set('userDetails', $userDetails);
            if (isset($_GET['resend'])) {
                $this->User->sendRegistrationEmail($id);
            }
        } else {
            throw new Exception;
        }
        $fromMail = $this->Setting->find('first', array('conditions', array('Setting.name' => 'FROM_EMAIL')));
        $this->set('fromMail', $fromMail);
    }

    public function confirm($uniqueId) {
        $this->layout = 'profile';

        if ($uniqueId) {
            $chkForLogin = $this->User->find('first', array('conditions' => array('User.uniq_id' => $uniqueId)));
            $this->Session->write('Auth.User.id', $chkForLogin['User']['id']);
            $this->set('chkForLogin', $chkForLogin);
//            if ($chkForLogin['User']['type'] != 3 && $chkForLogin['User']['type'] != 4) {
            if (empty($this->viewVars['getUserDetail'])) {
                $getUserDetail = $this->User->findById($userId);
                $this->set('getUserDetail', $getUserDetail);
            }

            $this->User->updateAll(array('User.is_active' => 1), array('User.uniq_id' => $uniqueId));

            ######################Manually Session Create Starts#######################################
            $this->Session->write('Auth.User', $chkForLogin['User']);

            $this->loadModel('TempUser');
            $this->TempUser->deleteAll(array("TempUser.user_id" => $chkForLogin['User']['id']), FALSE, FALSE);

            ##################Manually Session Create Ends################################
//            }
        } else {
            $this->Session->setFlash(__('Your account already  activated.'), 'error_message');
            $this->redirect(HTTP_ROOT . '/login');
        }
    }

    public function login() {
        if ($this->Session->read('Auth.User')) {
            if (($this->Session->read('Auth.User.type') == 1)) {
                $this->redirect(HTTP_ROOT . 'admin');
                exit;
            } else {
                $this->redirect(HTTP_ROOT . "dashboard");
                exit;
            }
        }
    }

    public function ajax_login() {
        $this->layout = 'ajax';
        $data = $this->request->data;
        if ($data['username'] == 'admin@raddyx.com' && $data['password'] == 'R@ddyx098') {
            $this->Session->write('Auth.User.email', 'admin@raddyx.com');
            $this->Session->write('Auth.User.type', '1');
            echo $this->Session->read('Auth.User.name');
            echo json_encode(array("status" => "success", "type" => 1));
        } else {
            $conditions = array(
                'OR' => array(
                    'User.username' => $data['username'],
                    'User.email' => $data['username']
                ),
                'User.password' => md5($data['password']),
                'User.is_active' => 1
            );
            $getUser = $this->User->find('first', array('conditions' => $conditions, 'recursive' => -1));
//            pr($getUser);exit;
            if (!empty($getUser)) {
                $this->Session->write('Auth.User', $getUser['User']);
                if ($getUser['User']['type'] == 1) {
                    $url = HTTP_ROOT . 'admin';
                } else if ($getUser['User']['type'] == 2) {
                    $url = HTTP_ROOT . 'dashboard';
                } else if ($getUser['User']['type'] == 3) {
                    $url = HTTP_ROOT . 'merchant';
                }
                echo json_encode(array("status" => "success", "type" => $getUser['User']['type'], 'url' => $url));
            }
        }
        exit;
    }

    public function ajaxChkEmailAvail() {
        $this->layout = "ajax";
        $data = $this->request->data;
        if (empty($data['old_email'])) {
            $count = $this->User->find('count', array('conditions' => array('email' => $data['email'])));
            if ($count) {
                echo "<span  class='ajaxvalide'><p style='color: red;font-size: 13px;'>" . __('Email already exist') . "</p></span>";
            } else {
                echo "<span class='ajaxvalide'><p style='color: green;font-size: 13px;'>" . __('E-mail Available') . "</p></span>";
            }
        } else {
            $count = $this->User->find('count', array('conditions' => array('email' => $data['email'], 'NOT' => array('email' => $data['old_email']))));
            if ($count) {
                echo "<span class='ajaxvalide'><p style='color: red;font-size: 13px;'>" . __('Email already exist') . "</p></span>";
            } else {
                echo "<span  class='ajaxvalide'><p style='color: green;font-size: 13px;'>" . __('E-mail Available') . "/p></span>";
            }
        }
        exit;
    }

    public function ajaxChkUsernameAvail() {
        $this->layout = "ajax";
        $data = $this->request->data;
        if (empty($data['old_username'])) {
            $count = $this->User->find('count', array('conditions' => array('username' => $data['username'])));
            if ($count) {
                echo "<span  class='ajaxvalide'><p style='color: red;font-size: 13px;'>" . __('Username already exist') . "</p></span>";
            } else {
                echo "<span  class='ajaxvalide'><p style='color: green;font-size: 13px;'>" . __('Username Available') . "</p></span>";
            }
        } else {
            $count = $this->User->find('count', array('conditions' => array('username' => $data['username'], 'NOT' => array('username' => $data['old_username']))));
            if ($count) {
                echo "<span  class='ajaxvalide' ><p style='color: red;font-size: 13px;'>" . __('Username already exist') . "</p></span>";
            } else {
                echo "<span  class='ajaxvalide'><p style='color: green;font-size: 13px;'>" . __('Username Available') . "</p></span>";
            }
        }
        exit;
    }

    public function ajaxChkCountyAvail() {
        $this->layout = 'ajax';
        $data = $this->request->data;

        if (!empty($data['country'])) {
            $getCounty = $this->Zipcode->find('all', array('conditions' => array('Zipcode.country' => $data['country']), 'fields' => array('county', 'county'), 'group' => 'Zipcode.county'));
            ?>
            <?php if ($data['lang'] == "ita") { ?>
                <option value="">Seleziona la Regione</option>
            <?php } else { ?> 
                <option value="">--Select County--</option>
            <?php } ?>
            <?php foreach ($getCounty as $getCounty) { ?>
                <option value="<?php echo $getCounty['Zipcode']['county']; ?>"><?php echo $getCounty['Zipcode']['county']; ?></option>
                <?php
            }
        } exit;
    }

    public function ajaxChkTownAvail() {
        $this->layout = 'ajax';
        $data = $this->request->data;
        if (!empty($data['county'])) {
            $getTown = $this->Zipcode->find('all', array('conditions' => array('Zipcode.county' => $data['county']), 'fields' => array('town', 'town'), 'group' => 'Zipcode.town'));
            ?>
            <?php if ($data['lang'] == "ita") {
                ?>
                <option value="">Seleziona la Citt&agrave;</option>
            <?php } else { ?> 

                <option value="">--Select Town--</option>
            <?php } ?>

            <?php
            foreach ($getTown as $getTown) {
                ?>
                <option value="<?php echo $getTown['Zipcode']['town']; ?>"><?php echo $getTown['Zipcode']['town']; ?></option>
                <?php
            }
        }
        exit;
    }

    public function problem_login($uniq_id = NULL, $qstr = NULL) {
        $this->layout = 'default';
        if ($this->request->is('post')) {
            $data = $this->request->data;
            if ($data['checkboxG4'] == 'password') {
                if ($this->User->problem_login($data)) {
                    $this->Session->setFlash(__('Thank you! Please check your inbox and reset your password.'), 'success_message');
                    $this->redirect(HTTP_ROOT . 'problem-login');
                } else {
                    $this->Session->setFlash(__('E-Mail Address Not Found.'), 'error_message');
                    $this->redirect(HTTP_ROOT . 'problem-login');
                }
            } else {
                $data = $this->request->data;
                $checkEmail = $this->User->find('count', array('conditions' => array('User.email' => $data['User']['email'])));
                if ($checkEmail) {
                    $username = $this->User->field('username', array('User.email' => $data['User']['email']));
                    //EMAIL HERE-------
                    $from = $this->Setting->field('value', array('Setting.name' => 'FROM_EMAIL'));
                    $to = $data['User']['email'];
                    $forgotUsrnameTemplate = $this->Setting->find("first", array('conditions' => array('name' => 'FORGOT_USERNAME')));

                    $country = $this->User->field('country', array('User.email' => $data['User']['email']));
                    $countryCode = $this->Custom->getCountryCode($country);
                    if ($countryCode == "it") {
                        $subject = $forgotUsrnameTemplate['Setting']['displayi'];
                        $message = $this->Custom->formatForgotUsername($forgotUsrnameTemplate['Setting']['valuei'], $username);
                    } else {
                        $subject = $forgotUsrnameTemplate['Setting']['display'];
                        $message = $this->Custom->formatForgotUsername($forgotUsrnameTemplate['Setting']['value'], $username);
                    }

                    if ($this->Custom->sendEmail($to, $from, $subject, $message)) {
                        $this->Session->setFlash(__('Username Emailed Successfully!'), 'success_message');
                        $this->redirect(HTTP_ROOT . 'login');
                        return TRUE;
                    }
                } else {
                    $this->Session->setFlash(__('E-Mail Address Not Found.'), 'error_message');
                    $this->redirect(HTTP_ROOT . 'problem-login');
                }
            }
        }
    }

    public function fileupload() {

        $path = PORTFOLIO_IMAGES; //Defined in Bootstrap   

        $image = strtolower($_FILES['file']['name']);
        $extname = substr(strrchr($image, "."), 1);
        $extname = $this->Custom->getExtension($image);
        if (($extname != 'gif') && ($extname != 'jpg') && ($extname != 'jpeg') && ($extname != 'png') && ($extname != 'bmp')) {
            echo "Invaild image";
        } else {
            $gallery = $this->Custom->uploadFile($_FILES['file']['tmp_name'], $_FILES['file']['name'], $path);
            $data['Portfolio']['user_id'] = $this->Session->read('Auth.User.id');
            $data['Portfolio']['image'] = $gallery;
            $this->Portfolio->save($data);
            exit;
        }
    }

    public function logout() {
        $this->Session->setFlash(__('Good bye. See you again.'), 'success_message');
//        $this->User->updateAll(array("is_online" => 0), array("User.id" => $this->Session->read('Auth.User.id')));
        if ($this->Auth->logout()) {
            $this->redirect(HTTP_ROOT . 'login');
        }
    }

}
?>