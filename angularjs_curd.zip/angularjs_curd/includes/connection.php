<?php

$link = mysqli_connect("localhost", "root", "", "angular_curd");
mysqli_select_db($link, "users");
?>