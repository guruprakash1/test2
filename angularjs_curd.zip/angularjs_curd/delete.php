<?php

//echo 'Jai Jagannath Swami';
//exit;
$id = $_GET["id"];
include 'includes/connection.php';
$sql = "DELETE FROM users WHERE id='{$id}'";
$query = mysqli_query($link, $sql);
?>