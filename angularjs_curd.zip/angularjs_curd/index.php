<html>
    <head>
        <title>Jai Jagannath Swami</title>    
        <link type="text/css" rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
        <!-- Angular JS -->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.1/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/angular.js"></script>
        <!--<script type="text/javascript" src="js/angular.min.js"></script>-->
        <script type="text/javascript" src="js/angular-route.min.js"></script>

        <!-- MY App -->
        <script type="text/javascript" src="app/routes.js"></script>
        <!-- App Controller -->
        <script type="text/javascript" src="app/controllers/UserController.js"></script>
    </head>
    <body ng-app="my-App">
        <!--<h1>Angularjs <span>curd</span> by <span>Mr. Prakash Kumar Guru</span></h1>-->
    <ng-view></ng-view>     
</body>
</html>