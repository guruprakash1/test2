<?php

//echo 'Jai Jagannath Swami';
//exit;
$id = $_GET["id"];
include 'includes/connection.php';
$sql = "SELECT * FROM users WHERE id='{$id}'";
$query = mysqli_query($link, $sql);
$results = mysqli_fetch_assoc($query);
echo json_encode($results);
?>