var app = angular.module('my-App', ['ngRoute']);

app.config(['$routeProvider',
    function ($routeProvider) {
        $routeProvider.
                when('/', {
                    templateUrl: 'templates/listing.html',
                    controller: 'UserController'
                });
    }]);