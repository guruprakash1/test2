app.controller('UserController', function ($scope, $http, $timeout) {

    $scope.data = [];
    $scope.libraryTemp = {};
    $scope.totalItemsTemp = {};
    $scope.listingUsers = function () {
//        console.log('Jai Jagannath Swami');
        $http.post('listing.php').then(function (response) {
//            var users = [{name: 'Prakash', email: 'prakash.kumarguru@gmail.com', age: '25', gender: 'Male', dob: '29/11/2016'}, {name: 'Pradeepta', email: 'pradeepta20@gmail.com', age: '26', gender: 'Male', dob: '30/11/2016'}];
            $scope.userListings = response.data;
        });
    }

    // switch flag
    $scope.switchBool = function (value) {
        $scope[value] = !$scope[value];
    };

//    $scope.errorTextAlert = "Some error occured";
//    $scope.showErrorAlert = true;

    $scope.addUser = function () {
        var data = $scope.user;
        $http.post('insert.php', data).then(function (response) {
            $scope.user = '';
            $scope.userListings = response.data;
            $('.modal').hide();
            $scope.successTextAlert = "User added successfully";
            $scope.showSuccessAlert = true;
            $timeout(function () {
                $scope.showSuccessAlert = false;
            }, 3000);
//            $scope.data = {};
//            $scope.userForm.$setUntouched();
//            $scope.userForm.user.name = {};
//            $scope.user.push(response.data);            
        });
    }
    $scope.edit = function (id) {
        $http.post('edit.php?id=' + id).then(function (response) {
            $scope.user = response.data;
        });
    }
    $scope.saveEdit = function () {
        var data = $scope.user;
        $http.post('update.php', data).then(function (response) {
            $scope.userListings = response.data;
            $('.modal').hide();
            $scope.successTextAlert = "User updated successfully";
            $scope.showSuccessAlert = true;
            $timeout(function () {
                $scope.showSuccessAlert = false;
            }, 3000);
        });
    }

    $scope.remove = function (user, index) {
        var result = confirm("Are you sure delete this user?");
        if (result) {
            $http.post('delete.php?id=' + user.id).then(function () {
                $scope.userListings.splice(index, 1);
                $scope.successTextAlert = "User deleted successfully";
                $scope.showSuccessAlert = true;
                $timeout(function () {
                    $scope.showSuccessAlert = false;
                }, 3000);
            });
        }
    }

//  Search Section Starts here \\

//    $scope.totalItems = 0;
//    $scope.pageChanged = function (newPage) {
//        getResultsPage(newPage);
//    };
//
//    getResultsPage(1);
//    function getResultsPage(pageNumber) {
//        if (!$.isEmptyObject($scope.libraryTemp)) {
//            dataFactory.httpRequest(URL + '/api/getData.php?search=' + $scope.searchText + '&page=' + pageNumber).then(function (data) {
//                $scope.data = data.data;
//                $scope.totalItems = data.total;
//            });
//        } else {
//            dataFactory.httpRequest(URL + '/api/getData.php?page=' + pageNumber).then(function (data) {
//                $scope.data = data.data;
//                $scope.totalItems = data.total;
//            });
//        }
//    }
//    $scope.searchDB = function () {
//        if ($scope.searchText.length >= 3) {
//            if ($.isEmptyObject($scope.libraryTemp)) {
//                $scope.libraryTemp = $scope.data;
//                $scope.totalItemsTemp = $scope.totalItems;
//                $scope.data = {};
//            }
//            getResultsPage(1);
//        } else {
//            if (!$.isEmptyObject($scope.libraryTemp)) {
//                $scope.data = $scope.libraryTemp;
//                $scope.totalItems = $scope.totalItemsTemp;
//                $scope.libraryTemp = {};
//            }
//        }
//    }
//  Search Section Ends here \\

});