<?php

//echo 'Jai Jagannath Swami';
//exit;
include 'includes/connection.php';
$sql = "SELECT * FROM users order by id DESC";
$query = mysqli_query($link, $sql);
$results = array();
while ($fetchData = mysqli_fetch_assoc($query)) {
    $results[] = $fetchData;
}
echo json_encode($results);
?>