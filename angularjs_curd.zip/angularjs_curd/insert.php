<?php

//echo 'Jai Jagannath Swami';
//exit;
include 'includes/connection.php';
$post = file_get_contents('php://input');
$post = json_decode($post);
$name = $post->name;
$email = $post->email;
$age = $post->age;
$explode = explode('/', $post->dob);
$dob = $explode[2] . '-' . $explode[1] . '-' . $explode[0];
$gender = ($post->gender == 'Male' ? 1 : 2);
$query = "INSERT INTO users SET name = '$name',email='$email',age=$age,dob='$dob',gender=$gender,created=NOW()";
mysqli_query($link, $query);
//$get_last_insert_id = mysqli_insert_id($link);
$sql = "SELECT * FROM users order by id DESC";
$query = mysqli_query($link, $sql);
$results = array();
while ($fetchData = mysqli_fetch_assoc($query)) {
    $results[] = $fetchData;
}
echo json_encode($results);
?>