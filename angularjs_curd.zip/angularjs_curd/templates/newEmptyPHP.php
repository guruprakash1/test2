<form method="POST" name="editUser" id="editUser" role="form" novalidate ng-submit="editUser.$valid && editUser()">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Create User</h4>
    </div>
    <div class="modal-body">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <strong>Name : </strong>
                    <div class="form-group">
                        <input ng-model="user.id" type="hidden" placeholder="Name" name="id" class="form-control" />
                        <input ng-model="user.name" type="text" placeholder="Name" name="name" class="form-control" required />
                        <!--<p ng-show="addUser.form.name.$error.required">Name is required</p>-->
                        <div ng-show="editUser.$submitted || editUser.name.$touched">
                            <p ng-show="editUser.name.$error.required"><font color="red">&nbsp;&nbsp;Name is required!</font></p>                                     
                        </div>
                    </div>
                </div>                        
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <strong>Email : </strong>
                    <div class="form-group">
                        <input ng-model="user.email" type="email" placeholder="Email" name="email" class="form-control" required />                                 
                        <div ng-show="editUser.$submitted || editUser.email.$touched">
                            <p ng-show="editUser.email.$error.required"><font color="red">&nbsp;&nbsp;Email is required!</font></p>                                     
                            <p ng-show="editUser.email.$error.email"><font color="red">&nbsp;&nbsp;Please enter valid email!</font></p>                                     
                        </div>
                    </div>
                </div>                        
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <strong>Age : </strong>
                    <div class="form-group">
                        <input ng-model="user.age" type="text" placeholder="Age" name="age" class="form-control" required ng-pattern="/^[0-9]{1,3}$/"/>                                  
                        <div ng-show="editUser.$submitted || editUser.age.$touched">
                            <p ng-show="editUser.age.$error.required"><font color="red">&nbsp;&nbsp;Age is required!</font></p>                                     
                            <p ng-show="editUser.age.$error.pattern"><font color="red">&nbsp;&nbsp;Invalid age!</font></p>                                     
                        </div>
                    </div>
                </div>                       
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <strong>Date of birth : </strong>
                    <div class="form-group">
                        <input ng-model="user.dob" type="text" placeholder="Date of birth" name="dob" class="form-control" required />                                 
                        <div ng-show="editUser.$submitted || editUser.dob.$touched">
                            <p ng-show="editUser.dob.$error.required"><font color="red">&nbsp;&nbsp;Date of birth is required!</font></p>                                  
                        </div>
                    </div>
                </div>    
                <div class="col-xs-12 col-sm-6 col-md-6">
                    <strong>Gender : </strong>
                    <div class="form-group">
                        <label class="radio-inline">
                            <input ng-model="user.gender" type="radio" value="Male" name="gender" ng-required="!gender">Male
                        </label>
                        <label class="radio-inline">
                            <input ng-model="user.gender" type="radio" value="Female" name="gender" ng-required="!gender">Female
                        </label>
                        <div ng-show="editUser.$submitted || editUser.gender.$touched">
                            <p ng-show="editUser.gender.$error.required"><font color="red">&nbsp;&nbsp;Gender is required!</font></p>                                   
                        </div>
                    </div>
                </div>                        
            </div>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
            <!--<button type="submit" ng-disabled="editUser.$invalid" class="btn btn-primary">Submit</button>-->
        </div>
    </div>
</form>