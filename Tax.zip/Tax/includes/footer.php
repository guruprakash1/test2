
<h1 align="center" style="color:blue;margin-left:30px; background-color:#33CC66; width:500px;
margin:0 auto;">copyright &copy; <?php echo date('Y');?> allright reserved.</h1>