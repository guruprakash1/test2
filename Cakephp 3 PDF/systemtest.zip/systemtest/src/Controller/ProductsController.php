<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;

class ProductsController extends AppController {

    public function initialize() {
        parent::initialize();
        //Load Components
        $this->loadComponent('Custom');
        $this->loadComponent('Paginator');
        //Load Model
        $this->loadModel('Products');
        $this->loadModel('ProductColors');
        $this->loadModel('ProductImages');
        $this->loadModel('ProductSizes');
    }

    public function beforeFilter(Event $event) {
        $this->viewBuilder()->layout('default');
    }

    public function index() {
        $conditions = [];
        $config = [
            'conditions' => $conditions,
            'order' => ['Products.id' => 'DESC'],
            'contain' => [],
            'limit' => 4,
        ];
        $products = $this->Paginator->paginate($this->Products->find(), $config);
        $this->set('products', $products);
    }

    /**
     * View method
     *
     * @param string|null $id Product id.
     * @return void
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function view($id = null) {
        $product = $this->Products->get($id, [
            'contain' => ['ProductColors', 'ProductImages', 'ProductSizes']
        ]);
        $this->set('product', $product);
        $this->set('_serialize', ['product']);
    }

    /**
     * Add method
     *
     * @return void Redirects on successful add, renders view otherwise.
     */
    public function add() {
        $product = $this->Products->newEntity();
        if ($this->request->is('post')) {
            $data = $this->request->data;
            $product = $this->Products->patchEntity($product, $data);
            if ($this->Products->save($product)) {
                $this->_addProductImages($product->id, @$data['images']);
                $this->_addProductColors($product->id, @$data['colors']);
                $this->_addProductSizes($product->id, @$data['sizes']);
                $this->Flash->success(__('The product has been added successfully.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The product could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('product'));
        $this->set('_serialize', ['product']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Product id.
     * @return void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null) {
        $product = $this->Products->get($id, [
            'contain' => ['ProductImages', 'ProductColors', 'ProductSizes']
        ]);
        $data = $this->request->data;
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->data;
            $product = $this->Products->patchEntity($product, $data);
            if ($this->Products->save($product)) {
                $this->_addProductImages($product->id, @$data['images']);
                $this->_addProductColors($product->id, @$data['colors']);
                $this->_addProductSizes($product->id, @$data['sizes']);
                $this->Flash->success(__('The product has been updated successfully.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The product could not be saved. Please, try again.'));
            }
        }
        $this->set(compact('product'));
        $this->set('_serialize', ['product']);
    }

    private function _addProductImages($productID, $images) {
        if (!empty($images)) {
            foreach ($images as $image) {
                if (!empty($image['name'])) {
                    $filename = $this->Custom->uploadImage($image['name'], $image['tmp_name'], PRODUCT_IMAGES);
                    if ($filename) {
                        $productImage = $this->ProductImages->newEntity();
                        $productImage->product_id = $productID;
                        $productImage->image = $filename;
                        $this->ProductImages->save($productImage);
                    }
                }
            }
        }
    }

    private function _addProductColors($productID, $colors) {
        $this->ProductColors->deleteAll(['product_id' => $productID]);
        if (!empty($colors)) {
            foreach ($colors as $color) {
                if (!empty($color)) {
                    $productColor = $this->ProductColors->newEntity();
                    $productColor->product_id = $productID;
                    $productColor->color = $color;
                    $this->ProductColors->save($productColor);
                }
            }
        }
    }

    private function _addProductSizes($productID, $sizes) {
        $this->ProductSizes->deleteAll(['product_id' => $productID]);
        if (!empty($sizes)) {
            foreach ($sizes as $size) {
                if (!empty($size)) {
                    $productSize = $this->ProductSizes->newEntity();
                    $productSize->product_id = $productID;
                    $productSize->size = $size;
                    $this->ProductSizes->save($productSize);
                }
            }
        }
    }

    /**
     * Delete method
     *
     * @param string|null $id Product id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function delete($id = null) {
        $this->request->allowMethod(['post', 'delete']);
        $product = $this->Products->get($id);
        $productImages = $this->ProductImages->find()->where(['product_id' => $product->id]);
        if ($productImages->count() > 0) {
            foreach ($productImages as $productImage) {
                $image = PRODUCT_IMAGES . $productImage->image;
                @unlink($image);
            }
        }
        if ($this->Products->delete($product)) {
            $this->Flash->success(__('The product has been deleted.'));
        } else {
            $this->Flash->error(__('The product could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }

    public function deleteImage($id = null) {
        $entity = $this->ProductImages->get($id);
        $image = PRODUCT_IMAGES . $entity->image;
        if ($this->ProductImages->delete($entity)) {
            @unlink($image);
            $this->Flash->success(__('The image has been deleted.'));
        } else {
            $this->Flash->error(__('The image could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->referer());
    }

}
