<?php

namespace App\Controller\Component;

use Cake\Network\Email\Email;
//use Cake\Mailer\Email;
use Cake\Controller\Component;
use Cake\ORM\TableRegistry;

class CustomComponent extends Component {

    function __construct($prompt = null) {
        
    }

    function uploadImage($name, $tmpName, $path) {
        if ($name) {
            $file = strtolower($name);
            $fileExtention = pathinfo($name, PATHINFO_EXTENSION);
            if (in_array($fileExtention, ['gif', 'jpg', 'jpeg', 'png'])) {  //'bmp', 'doc', 'docx', 'pdf'
                if (!is_dir($path)) {
                    mkdir($path);
                }
                $fileName = md5(time() . rand(1111, 9999)) . "." . $fileExtention;
                move_uploaded_file($tmpName, "$path/$fileName");
                return $fileName;
            }
        }
        return FALSE;
    }

}
