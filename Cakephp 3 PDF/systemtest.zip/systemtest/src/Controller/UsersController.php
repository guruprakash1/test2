<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Mailer\Email;
use Cake\Network\Request;
use Cake\ORM\TableRegistry;

class UsersController extends AppController {

    public function initialize() {
        parent::initialize();
        //Load Components
//        $this->loadComponent('Custom');
        //Load Model
        $this->loadModel('Users');
    }

    public function beforeFilter(Event $event) {
//        $this->viewBuilder()->layout('admin');
        $this->Auth->allow(['login']);
    }

    public function dashboard() {
        
    }

    public function login() {
        $this->viewBuilder()->layout('');
        if ($this->Auth->user('id')) {
            return $this->redirect(['controller' => 'Users', 'action' => 'dashboard']);
        }
        if ($this->request->is('post')) {
            $data = $this->request->data;
            $user = $this->Auth->identify();
            if ($user) {
                $allowLogin = $this->Users->find()->where(['Users.email' => $data['email'], 'Users.is_active' => 1])->count();
                if ($allowLogin > 0) {
                    $this->Auth->setUser($user);
                    //$this->Flash->success(__('Login successfull'));
                    return $this->redirect(['controller' => 'Products', 'action' => 'index']);
                } else {
                    $this->Flash->error(__('Invalid email or password, try again'));
                    return $this->redirect($this->referer());
                }
            } else {
                $this->Flash->error(__('Invalid email or password, try again'));
                return $this->redirect($this->referer());
            }
        }
    }

    public function logout() {
        session_destroy();
        $this->Auth->logout();
        $this->Flash->success(__('Logout Successfull'));
        return $this->redirect(['controller' => 'Users', 'action' => 'login']);
    }

}
