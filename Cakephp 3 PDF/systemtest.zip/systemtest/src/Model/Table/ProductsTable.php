<?php

namespace App\Model\Table;

use App\Model\Entity\Product;
use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Products Model
 *
 * @property \Cake\ORM\Association\HasMany $ProductColors
 * @property \Cake\ORM\Association\HasMany $ProductImages
 * @property \Cake\ORM\Association\HasMany $ProductSizes
 */
class ProductsTable extends Table {

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config) {
        parent::initialize($config);

        $this->table('products');
        $this->displayField('id');
        $this->primaryKey('id');

        $this->addBehavior('Timestamp');

        $this->hasMany('ProductColors', [
            'foreignKey' => 'product_id',
            'dependent' => TRUE,
        ]);
        $this->hasMany('ProductImages', [
            'foreignKey' => 'product_id',
            'dependent' => TRUE,
        ]);
        $this->hasMany('ProductSizes', [
            'foreignKey' => 'product_id',
            'dependent' => TRUE,
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator) {
        $validator
                ->add('id', 'valid', ['rule' => 'numeric'])
                ->allowEmpty('id', 'create');

        $validator
                ->requirePresence('product_name', 'create')
                ->notEmpty('product_name');

        $validator
                ->requirePresence('product_url', 'create')
                ->notEmpty('product_url');

        $validator
                ->add('product_price', 'valid', ['rule' => 'numeric'])
                ->requirePresence('product_price', 'create')
                ->notEmpty('product_price');

        $validator
                ->requirePresence('product_description', 'create')
                ->notEmpty('product_description');

        $validator
                ->requirePresence('seo_title', 'create')
                ->notEmpty('seo_title');

        $validator
                ->requirePresence('seo_keyword', 'create')
                ->notEmpty('seo_keyword');

        $validator
                ->requirePresence('seo_description', 'create')
                ->notEmpty('seo_description');

        $validator
                ->add('is_active', 'valid', ['rule' => 'numeric'])
                ->requirePresence('is_active', 'create')
                ->notEmpty('is_active');

        return $validator;
    }

}
