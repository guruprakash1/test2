-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2017 at 10:44 AM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `systemtest`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
`id` int(11) NOT NULL,
  `product_name` varchar(256) NOT NULL,
  `product_url` varchar(256) NOT NULL,
  `product_price` double NOT NULL,
  `product_description` longtext NOT NULL,
  `seo_title` varchar(100) NOT NULL,
  `seo_keyword` varchar(100) NOT NULL,
  `seo_description` text NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes/0=No',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_url`, `product_price`, `product_description`, `seo_title`, `seo_keyword`, `seo_description`, `is_active`, `created`, `modified`) VALUES
(4, 'Samsung gallaxy J2', 'samsung-gallaxy-j2', 8000, 'Samsung gallaxy J2', 'Samsung gallaxy J2', 'Samsung gallaxy J2', 'Samsung gallaxy J2', 1, '2016-05-20 13:49:53', '2017-09-06 08:11:06'),
(5, 'Samsung Galaxy J3 ', 'samsung-galaxy-j3', 8990, 'Samsung Galaxy J3', 'Samsung Galaxy J3 ', 'Samsung Galaxy J3 ', 'Samsung Galaxy J3 ', 1, '2016-05-23 05:49:21', '2017-09-05 10:32:35'),
(6, 'Micromax Canvas 5 E481', 'micromax-canvas-5-e481', 11490, 'Micromax Canvas 5 E481', 'Micromax Canvas 5 E481', 'Micromax Canvas 5 E481', 'Micromax Canvas 5 E481', 1, '2016-05-23 05:58:22', '2017-09-05 10:32:35'),
(7, 'Micromax Canvas 5 E421', 'micromax-canvas-5-e421', 8500, 'Micromax Canvas 5 E421', 'Micromax Canvas 5 E421', 'Micromax Canvas 5 E421', 'Micromax Canvas 5 E421', 1, '2016-05-23 06:03:24', '2017-09-05 10:32:35'),
(8, 'Samsung Galaxy S5 (Gold, 16 GB)', 'samsung-galaxy-s5-gold-16-gb', 15999, 'Samsung Galaxy S5 (Gold, 16 GB)', 'Samsung Galaxy S5 (Gold, 16 GB)', 'Samsung Galaxy S5 (Gold, 16 GB)', 'Samsung Galaxy S5 (Gold, 16 GB)', 1, '2016-05-23 06:08:21', '2017-09-06 08:43:47');

-- --------------------------------------------------------

--
-- Table structure for table `product_colors`
--

DROP TABLE IF EXISTS `product_colors`;
CREATE TABLE IF NOT EXISTS `product_colors` (
`id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `color` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_colors`
--

INSERT INTO `product_colors` (`id`, `product_id`, `color`) VALUES
(5, 4, 'Blue'),
(6, 4, 'Red'),
(9, 22, 'Yellow'),
(10, 23, 'Blue'),
(11, 23, 'Yellow');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
CREATE TABLE IF NOT EXISTS `product_images` (
`id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `image`) VALUES
(4, 4, '10d04d0022b54724eb9c391b5c3de07b.jpg'),
(5, 4, '10212ea4ca5a5f667e0134b7e0d05695.jpg'),
(6, 22, '85d5948127726676540f70177612d52b.jpg'),
(7, 22, '72781f0cce0ac483963db7d919d007c2.jpg'),
(8, 22, 'd186ac510f05b90d9041a2480d9c241e.jpg'),
(9, 23, 'bf165e68de2b10fe7f75d9b06aa4dd5f.jpg'),
(12, 8, 'e238fd726244ae0ef8c96a530daf96f6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_sizes`
--

DROP TABLE IF EXISTS `product_sizes`;
CREATE TABLE IF NOT EXISTS `product_sizes` (
`id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `size` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_sizes`
--

INSERT INTO `product_sizes` (`id`, `product_id`, `size`) VALUES
(5, 4, '30'),
(6, 4, '32'),
(7, 4, '30'),
(10, 22, '30'),
(11, 22, '40'),
(12, 23, '30'),
(13, 23, '40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `uniqid` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `last_login_ip` varchar(50) NOT NULL,
  `last_login_date` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `uniqid`, `name`, `email`, `password`, `is_active`, `created`, `modified`, `last_login_ip`, `last_login_date`) VALUES
(1, 'b6296841c890dab6b86bea18657bae0a', 'Admin', 'admin@muvi.com', '$2y$10$CQ7SeeDokW8ofNzoaQhR4eBkjeI5DTfLAqyPj.DQ9J5Nc6VAunIdq', 1, '2016-05-17 14:00:00', '0000-00-00 00:00:00', '1234567', '0000-00-00 00:00:00'),
(2, 'b6296841c890dab6b86bea18657bae0a22', 'Prakash', 'admin@raddyx.com', '$2y$10$CQ7SeeDokW8ofNzoaQhR4eBkjeI5DTfLAqyPj.DQ9J5Nc6VAunIdq', 1, '2016-05-24 14:32:40', '0000-00-00 00:00:00', '0', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_colors`
--
ALTER TABLE `product_colors`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sizes`
--
ALTER TABLE `product_sizes`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `product_colors`
--
ALTER TABLE `product_colors`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `product_sizes`
--
ALTER TABLE `product_sizes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
